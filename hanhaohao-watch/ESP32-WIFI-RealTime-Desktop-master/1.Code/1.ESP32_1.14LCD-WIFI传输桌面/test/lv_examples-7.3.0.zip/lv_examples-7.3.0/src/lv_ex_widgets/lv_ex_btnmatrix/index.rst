C
^

Simple Button matrix 
""""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_btnmatrix/lv_ex_btnmatrix_1.*
  :alt: Simple Button matrix example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_btnmatrix/lv_ex_btnmatrix_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
